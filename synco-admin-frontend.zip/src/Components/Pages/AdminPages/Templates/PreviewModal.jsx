import React, { useState, useCallback, useEffect } from "react";
import parse from "html-react-parser";
import { useCommunicationTemplate } from "../contexts/CommunicationContext";
import { useNavigate, useSearchParams } from "react-router-dom";  // ✅ to read URL params

export default function PreviewModal({ mode_of_communication, title, category, tags, sender, message, blocks, onClose, subject, editMode, templateId }) {
  const { createCommunicationTemplate, updateCommunicationTemplate } = useCommunicationTemplate();
  const navigate = useNavigate();

  const [previewData, setPreviewData] = useState({
    subject: subject || "",
    blocks: blocks.map(b => ({ ...b })) // clone to avoid mutating props
  });
  const convertBlobToBase64 = async (blobUrl) => {
    const response = await fetch(blobUrl);
    const blob = await response.blob();
    return new Promise((resolve) => {
      const reader = new FileReader();
      reader.readAsDataURL(blob);
      reader.onloadend = () => resolve(reader.result);
    });
  };
  const convertNestedImages = async (blocks) => {
    for (let i = 0; i < blocks.length; i++) {
      const block = blocks[i];

      // Top-level image
      if (block.type === "image" && block.url?.startsWith("blob")) {
        block.url = await convertBlobToBase64(block.url);
      }

      // SectionGrid children
      if (block.type === "sectionGrid" && Array.isArray(block.columns)) {
        for (let ci = 0; ci < block.columns.length; ci++) {
          for (let c = 0; c < block.columns[ci].length; c++) {
            const child = block.columns[ci][c];
            if (child.type === "image" && child.url?.startsWith("blob")) {
              child.url = await convertBlobToBase64(child.url);
            }
          }
        }
      }

      // Custom Section (BG and Children)
      if (block.type === "customSection") {
        if (block.backgroundImage?.startsWith("blob")) {
          block.backgroundImage = await convertBlobToBase64(block.backgroundImage);
        }
        if (Array.isArray(block.children)) {
          for (let child of block.children) {
            if (child.type === "logo" && child.url?.startsWith("blob")) {
              child.url = await convertBlobToBase64(child.url);
            }
          }
        }
      }

      // CardRow images
      if (block.type === "cardRow" && Array.isArray(block.cards)) {
        for (let card of block.cards) {
          if (card.url?.startsWith("blob")) {
            card.url = await convertBlobToBase64(card.url);
          }
        }
      }
    }
    return blocks;
  };
  console.log('editMode', editMode)

  // ✅ Save final preview data
  const handleSavePreview = async () => {
    try {
      const formData = new FormData();

      // ✅ deep clone (DO NOT mutate React state)
      const finalBlocks = JSON.parse(JSON.stringify(previewData.blocks));

      let imageIndex = 1;

      const collectImages = async (block) => {
        if ((block.type === "image" || block.type === "banner" || block.type === "card") && block.url?.startsWith("blob")) {
          const response = await fetch(block.url);
          const blob = await response.blob();
          const fieldName = `image_${imageIndex}`;
          const file = new File([blob], `${fieldName}.png`, { type: blob.type });
          formData.append(fieldName, file);
          block.url = fieldName;
          imageIndex++;
        }

        if (block.type === "customSection" && block.backgroundImage?.startsWith("blob")) {
          const response = await fetch(block.backgroundImage);
          const blob = await response.blob();
          const fieldName = `bg_${imageIndex}`;
          const file = new File([blob], `${fieldName}.png`, { type: blob.type });
          formData.append(fieldName, file);
          block.backgroundImage = fieldName;
          imageIndex++;
        }

        if (block.style?.backgroundImage?.startsWith("blob")) {
          const response = await fetch(block.style.backgroundImage);
          const blob = await response.blob();
          const fieldName = `style_bg_${imageIndex}`;
          const file = new File([blob], `${fieldName}.png`, { type: blob.type });
          formData.append(fieldName, file);
          block.style.backgroundImage = fieldName;
          imageIndex++;
        }

        if (block.type === "sectionGrid" && Array.isArray(block.columns)) {
          for (const column of block.columns) {
            for (const child of column) await collectImages(child);
          }
        }

        if (block.type === "customSection" && Array.isArray(block.children)) {
          for (const child of block.children) await collectImages(child);
        }

        if (block.type === "cardRow" && Array.isArray(block.cards)) {
          for (const card of block.cards) {
            if (card.url?.startsWith("blob")) {
              const response = await fetch(card.url);
              const blob = await response.blob();
              const fieldName = `card_row_image_${imageIndex}`;
              const file = new File([blob], `${fieldName}.png`, { type: blob.type });
              formData.append(fieldName, file);
              card.url = fieldName;
              imageIndex++;
            }
          }
        }
      };

      // extract all images
      for (const block of finalBlocks) {
        await collectImages(block);
      }

      // JSON content
      const contentJSON = JSON.stringify({
        subject: previewData.subject,
        blocks: finalBlocks,
      });

      // append form fields
      formData.append("mode_of_communication", mode_of_communication.value);
      formData.append("title", title);

      // ✅ category MUST be array
      formData.append(
        "template_category_id",
        JSON.stringify(Array.isArray(category) ? category : [category])
      );

      formData.append("tags", JSON.stringify(tags));
      formData.append("content", contentJSON);

      // ✅ DEBUG (this confirms payload is correct)
      console.log("FORM DATA:", ...formData.entries());

      await createCommunicationTemplate(formData);

      navigate("/templates/settingList");
    } catch (err) {
      console.error("Save Preview Error:", err);
    }
  };



  const handleUpdatePreview = async () => {
    try {
      const formData = new FormData();

      // ✅ deep clone (DO NOT mutate React state)
      const finalBlocks = JSON.parse(JSON.stringify(previewData.blocks));

      let imageIndex = 1;

      const collectImages = async (block) => {
        if ((block.type === "image" || block.type === "banner" || block.type === "card") && block.url?.startsWith("blob")) {
          const response = await fetch(block.url);
          const blob = await response.blob();
          const fieldName = `image_${imageIndex}`;
          const file = new File([blob], `${fieldName}.png`, { type: blob.type });
          formData.append(fieldName, file);
          block.url = fieldName;
          imageIndex++;
        }

        if (block.type === "customSection" && block.backgroundImage?.startsWith("blob")) {
          const response = await fetch(block.backgroundImage);
          const blob = await response.blob();
          const fieldName = `bg_${imageIndex}`;
          const file = new File([blob], `${fieldName}.png`, { type: blob.type });
          formData.append(fieldName, file);
          block.backgroundImage = fieldName;
          imageIndex++;
        }

        if (block.style?.backgroundImage?.startsWith("blob")) {
          const response = await fetch(block.style.backgroundImage);
          const blob = await response.blob();
          const fieldName = `style_bg_${imageIndex}`;
          const file = new File([blob], `${fieldName}.png`, { type: blob.type });
          formData.append(fieldName, file);
          block.style.backgroundImage = fieldName;
          imageIndex++;
        }

        if (block.type === "sectionGrid" && Array.isArray(block.columns)) {
          for (const column of block.columns) {
            for (const child of column) await collectImages(child);
          }
        }

        if (block.type === "customSection" && Array.isArray(block.children)) {
          for (const child of block.children) await collectImages(child);
        }

        if (block.type === "cardRow" && Array.isArray(block.cards)) {
          for (const card of block.cards) {
            if (card.url?.startsWith("blob")) {
              const response = await fetch(card.url);
              const blob = await response.blob();
              const fieldName = `card_row_image_${imageIndex}`;
              const file = new File([blob], `${fieldName}.png`, { type: blob.type });
              formData.append(fieldName, file);
              card.url = fieldName;
              imageIndex++;
            }
          }
        }
      };

      // extract all images
      for (const block of finalBlocks) {
        await collectImages(block);
      }

      // JSON content
      const contentJSON = JSON.stringify({
        subject: previewData.subject,
        blocks: finalBlocks,
      });

      // append form fields
      formData.append("mode_of_communication", mode_of_communication.value);
      formData.append("title", title);

      // ✅ category MUST be array
      formData.append(
        "template_category_id",
        JSON.stringify(Array.isArray(category) ? category : [category])
      );

      formData.append("tags", JSON.stringify(tags));
      formData.append("content", contentJSON);

      // ✅ DEBUG
      console.log("UPDATE FORM DATA:", [...formData.entries()]);

      await updateCommunicationTemplate(templateId, formData);

      navigate("/templates/settingList");
    } catch (err) {
      console.error("Update Preview Error:", err);
    }
  };


  return (

    <div className="pt-10">
      <div className="flex justify-end ">
        <button
          className="mt-5 bg-blue-600 w-full max-w-fit text-white px-4 py-2 rounded-lg flex justify-end"
          onClick={editMode ? handleUpdatePreview : handleSavePreview}
        >
          {editMode ? "Update Template" : "Save Template"}
        </button>

      </div>
      <div className="bg-white w-full max-w-[600px] m-auto overflow-auto ">

        {/* Header */}

        {/* ✅ Subject (render only once) */}
        {subject && (
          <h1 className="text-2xl font-semibold mb-6">{subject}</h1>
        )}

        {/* Loop blocks */}
        {blocks.map((block, i) => (
          <div
            key={i}
            className="mb-5"
            style={{
              padding: block.style?.padding,
              backgroundColor: block.style?.backgroundColor,
              backgroundImage: block.style?.backgroundImage ? `url(${block.style.backgroundImage})` : "none",
              backgroundSize: "cover",
              backgroundPosition: "center",
              textAlign: block.style?.textAlign,
              borderRadius: block.style?.borderRadius,
              border: block.style?.borderWidth > 0 ? `${block.style?.borderWidth}px solid ${block.style?.borderColor}` : "none",
              width: block.style?.width,
              maxWidth: block.style?.maxWidth || "100%",
              height: block.style?.height,
              marginTop: block.style?.marginTop || 0,
              marginBottom: block.style?.marginBottom || 20,
              fontFamily: block.style?.fontFamily,
              marginInline: block.style?.textAlign === "center" ? "auto" : block.style?.textAlign === "right" ? "0 0 0 auto" : "0 auto 0 0",
              display: block.style?.display || "block",
              flexDirection: block.style?.flexDirection || "row",
              gap: block.style?.gap ? `${block.style.gap}px` : "0px",
              alignItems: block.style?.alignItems || "stretch",
              justifyContent: block.style?.justifyContent || "start",
              boxShadow: block.style?.boxShadow || "none",
            }}
          >
            {/* CUSTOM SECTION */}
            {block.type === "customSection" && (
              <div
                style={{
                  backgroundImage: block.backgroundImage ? `url(${block.backgroundImage})` : "none",
                  backgroundSize: "cover",
                  backgroundPosition: "center",
                  minHeight: "300px",
                  display: "flex",
                  flexDirection: "column",
                  justifyContent: "center",
                }}
              >
                <div className="flex flex-col gap-6">
                  {block.children?.map((child) => (
                    <div key={child.id} style={{ textAlign: child.style?.textAlign }}>
                      {child.type === "heading" && (
                        <h2 style={{ fontSize: child.style?.fontSize, color: child.style?.textColor, fontWeight: child.style?.fontWeight }}>
                          {child.content}
                        </h2>
                      )}
                      {child.type === "text" && (
                        <p style={{ fontSize: child.style?.fontSize, color: child.style?.textColor, whiteSpace: "pre-wrap" }}>
                          {child.content}
                        </p>
                      )}
                      {child.type === "logo" && child.url && (
                        <img src={child.url} className="mx-auto max-h-16 object-contain" />
                      )}
                      {child.type === "button" && (
                        <button className="px-6 py-2 rounded-lg font-bold" style={{ backgroundColor: child.style?.backgroundColor || "#237FEA", color: "#fff" }}>
                          {child.content}
                        </button>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* CARD BLOCK */}
            {block.type === "card" && (
              <div className="flex flex-col gap-4">
                {block.url && <img src={block.url} className="w-full rounded-lg object-cover" style={{ maxHeight: 300 }} />}
                <div>
                  <h3
                    style={{
                      color: block.style?.textColor,
                      fontSize: `calc(${block.style?.fontSize}px + 4px)`,
                      fontWeight: "bold",
                    }}
                  >
                    {block.title}
                  </h3>
                  <p
                    style={{
                      color: block.style?.textColor,
                      fontSize: block.style?.fontSize,
                      fontWeight: block.style?.fontWeight,
                      opacity: 0.8,
                      marginTop: "4px",
                      whiteSpace: "pre-wrap",
                      overflowWrap: "break-word"
                    }}
                  >
                    {block.description}
                  </p>
                </div>
              </div>
            )}

            {/* HEADING BLOCK */}
            {block.type === "heading" && (
              <h1
                style={{
                  color: block.style?.textColor,
                  fontSize: block.style?.fontSize,
                  fontWeight: block.style?.fontWeight,
                  whiteSpace: "pre-wrap",
                  overflowWrap: "break-word"
                }}
              >
                {block.content}
              </h1>
            )}

            {block.type === "text" && (
              <div
                style={{
                  color: block.style?.textColor,
                  fontSize: block.style?.fontSize,
                  textAlign: block.style?.textAlign,
                  fontFamily: block.style?.fontFamily,
                  whiteSpace: "pre-wrap",
                  overflowWrap: "break-word"
                }}
                className="rich-text-content"
              >
                {parse(block.content || "")}
              </div>
            )}

            {/* BANNER BLOCK */}
            {block.type === "banner" && (
              <img
                src={block.url}
                className="w-full rounded-xl object-cover"
                style={{ maxHeight: 600 }}
              />
            )}

            {/* IMAGE BLOCK */}
            {block.type === "image" && (
              <img
                src={block.url}
                className="w-full max-h-100 rounded-lg object-contain"
              />
            )}

            {/* FEATURE GRID */}
            {block.type === "featureGrid" && (
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                {block.items?.map((item, idx) => (
                  <div key={idx} className=" text-left">
                    <p className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">{item.label}</p>
                    <p className="text-sm font-semibold text-gray-800 mt-1">{item.value}</p>
                  </div>
                ))}
              </div>
            )}

            {/* SOCIAL LINKS */}
            {block.type === "socialLinks" && (
              <div className="flex gap-4 justify-center">
                {block.links?.map((link, idx) => (
                  <a
                    key={idx}
                    href={link.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-blue-600 hover:text-blue-800 font-medium text-sm capitalize"
                  >
                    {link.platform}
                  </a>
                ))}
              </div>
            )}

            {/* NAVIGATION LINKS */}
            {block.type === "navigation" && (
              <div className="flex gap-6 justify-center">
                {block.links?.map((link, idx) => (
                  <a
                    key={idx}
                    href={link.url}
                    className="text-gray-600 hover:text-blue-600 font-semibold text-sm"
                  >
                    {link.label}
                  </a>
                ))}
              </div>
            )}

            {/* DIVIDER */}
            {block.type === "divider" && (
              <hr className="border-t-2 border-gray-100 w-full" />
            )}

            {/* ACCORDION */}
            {block.type === "accordion" && (
              <div className="space-y-2">
                {block.items?.map((item, idx) => (
                  <div key={idx} className="border border-gray-100 rounded-xl overflow-hidden shadow-sm">
                    <div className="bg-gray-50 p-3 font-semibold text-sm flex justify-between items-center">
                      <span>{item.title}</span>
                      <span className="text-gray-400">▼</span>
                    </div>
                    <div className="p-3 text-sm text-gray-600 bg-white">
                      {item.content}
                    </div>
                  </div>
                ))}
              </div>
            )}

            {/* BUTTON BLOCK */}
            {block.type === "btn" && (
              <button
                style={{
                  backgroundColor: block.style?.backgroundColor === "transparent" ? "#237FEA" : block.style?.backgroundColor,
                  color: block.style?.textColor,
                  fontSize: block.style?.fontSize,
                  borderRadius: block.style?.borderRadius || 8,
                }}
                className="px-8 py-3 transition-transform hover:scale-105"
              >
                {block.content}
              </button>
            )}

            {/* SECTION GRID */}
            {block.type === "sectionGrid" && (
              <div className={`grid gap-4 grid-cols-${block.columns.length}`}>
                {block.columns.map((col, ci) => (
                  <div key={ci}>
                    {col.map((child) => (
                      <div
                        key={child.id}
                        className="mb-3"
                        style={{ textAlign: child.style?.textAlign }}
                      >
                        {/* TEXT */}
                        {child.type === "text" && (
                          <p
                            style={{
                              color: child.style?.textColor,
                              fontSize: child.style?.fontSize,
                              whiteSpace: "pre-wrap",
                              overflowWrap: "break-word"
                            }}
                          >
                            {child.content}
                          </p>
                        )}

                        {/* IMAGE */}
                        {child.type === "image" && (
                          <img
                            src={child.url}
                            className="rounded-lg object-contain w-full"
                          />
                        )}

                        {/* BUTTON */}
                        {child.type === "btn" && (
                          <button
                            style={{
                              backgroundColor: child.style?.backgroundColor || "#237FEA",
                              color: child.style?.textColor || "#ffffff",
                              fontSize: child.style?.fontSize || 14,
                              borderRadius: child.style?.borderRadius || 4,
                            }}
                            className="px-4 py-2"
                          >
                            {child.content}
                          </button>
                        )}
                      </div>
                    ))}
                  </div>
                ))}
              </div>
            )}

            {/* CARD ROW */}
            {block.type === "cardRow" && (
              <div
                style={{
                  display: "flex",
                  flexDirection: block.style?.flexDirection || "row",
                  gap: block.style?.gap ? `${block.style.gap}px` : "20px",
                  alignItems: block.style?.alignItems || "stretch",
                  justifyContent: block.style?.justifyContent || "start",
                  flexWrap: "wrap",
                  width: "100%"
                }}
              >
                {(block.cards || []).map((card) => (
                  <div
                    key={card.id}
                    className="flex-1 min-w-[200px]"
                    style={{
                      backgroundColor: card.style?.backgroundColor,
                      borderRadius: card.style?.borderRadius,
                      padding: card.style?.padding,
                      border: "1px solid #eee",
                      display: "flex",
                      flexDirection: "column",
                      gap: "12px"
                    }}
                  >
                    {card.url && (
                      <img
                        src={card.url}
                        className="w-full rounded-lg object-cover"
                        style={{ height: "150px" }}
                      />
                    )}
                    <h4 style={{ margin: 0, fontSize: "16px", fontWeight: "bold", whiteSpace: "pre-wrap", overflowWrap: "break-word" }}>
                      {card.title}
                    </h4>
                    <p style={{ margin: 0, fontSize: "14px", color: "#666", whiteSpace: "pre-wrap", overflowWrap: "break-word" }}>
                      {card.description}
                    </p>
                  </div>
                ))}
              </div>
            )}

            {/* HERO SECTION */}
            {block.type === "heroSection" && (
              <div style={{ position: "relative", overflow: "hidden" }}>
                <div style={{
                  backgroundColor: block.style?.backgroundColor,
                  padding: `${block.style?.padding}px`,
                  paddingBottom: "100px",
                  textAlign: "center",
                  color: block.style?.textColor,
                  backgroundImage: block.style?.backgroundImage ? `url(${block.style.backgroundImage})` : "none",
                  backgroundSize: "cover",
                  backgroundPosition: "center",
                }}>
                  <div style={{ maxWidth: "600px", margin: "0 auto", position: "relative", zIndex: 10 }}>
                    <div style={{ width: "64px", height: "64px", backgroundColor: "rgba(255,255,255,0.2)", borderRadius: "50%", margin: "0 auto 24px auto", display: "flex", alignItems: "center", justifyContent: "center", fontSize: "24px", fontWeight: "bold" }}>S</div>
                    <h1 style={{ fontSize: "36px", fontWeight: "800", color: "inherit", margin: 0 }}>{block.title}</h1>
                    <p style={{ fontSize: "18px", fontWeight: "500", color: "inherit", opacity: 0.9, marginTop: "16px" }}>{block.subtitle}</p>
                    <div style={{ marginTop: "32px" }}>
                      <a href={block.buttonUrl} style={{ display: "inline-block", backgroundColor: "#FACC15", color: "#000", fontWeight: "bold", padding: "12px 32px", borderRadius: "9999px", textDecoration: "none", boxShadow: "0 10px 15px -3px rgba(0, 0, 0, 0.1)" }}>
                        {block.buttonText}
                      </a>
                    </div>
                  </div>
                </div>
                <div style={{ position: "absolute", bottom: 0, left: 0, width: "100%", lineHeight: 0 }}>
                  <svg viewBox="0 0 1440 320" style={{ width: "100%", height: "auto", display: "block" }}>
                    <path fill="#ffffff" fillOpacity="1" d="M0,224L48,213.3C96,203,192,181,288,181.3C384,181,480,203,576,224C672,245,768,267,864,261.3C960,256,1056,224,1152,197.3C1248,171,1344,149,1392,138.7L1440,128L1440,320L1392,320C1344,320,1248,320,1152,320C1056,320,960,320,864,320C768,320,672,320,576,320C480,320,384,320,288,320C192,320,96,320,48,320L0,320Z"></path>
                  </svg>
                </div>
              </div>
            )}

            {/* INFO BOX */}
            {block.type === "infoBox" && (
              <div>
                <h3 style={{ textAlign: "center", fontSize: "24px", fontWeight: "bold", color: "#237FEA", marginBottom: "24px", fontFamily: "Handlee, cursive" }}>{block.title}</h3>
                <div style={{
                  backgroundColor: block.style?.backgroundColor,
                  borderRadius: block.style?.borderRadius,
                  border: `${block.style?.borderWidth}px solid ${block.style?.borderColor}`,
                  padding: "20px",
                  display: "grid",
                  gridTemplateColumns: "repeat(4, 1fr)",
                  gap: "10px",
                  alignItems: "center"
                }}>
                  {block.items?.map((item, i) => (
                    <div key={i} style={{ textAlign: "center", borderRight: i < block.items.length - 1 ? "1px solid #d1d5db" : "none", padding: "0 8px" }}>
                      <p style={{ fontSize: "12px", fontWeight: "bold", color: "#1f2937", margin: "0 0 4px 0" }}>{item.label}</p>
                      <div style={{ fontSize: "14px", color: "#4b5563", margin: 0 }}>{parse(item.value || "")}</div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* VIDEO GRID */}
            {block.type === "videoGrid" && (
              <div style={{ display: "grid", gridTemplateColumns: "repeat(2, 1fr)", gap: "24px" }}>
                {block.items?.map((item, i) => (
                  <div key={i} style={{ position: "relative", borderRadius: "12px", overflow: "hidden", backgroundColor: "#000", aspectRatio: "16/9", display: "flex", alignItems: "center", justifyContent: "center" }}>
                    {item.thumbnail && <img src={item.thumbnail} style={{ position: "absolute", top: 0, left: 0, width: "100%", height: "100%", objectFit: "cover", opacity: 0.6 }} />}
                    <div style={{ width: "48px", height: "48px", backgroundColor: "rgba(255,255,255,0.2)", borderRadius: "50%", display: "flex", alignItems: "center", justifyContent: "center", border: "1px solid rgba(255,255,255,0.5)", position: "relative", zIndex: 10 }}>
                      <span style={{ color: "white", fontSize: "20px" }}>▶</span>
                    </div>
                    <div style={{ position: "absolute", bottom: 0, left: 0, width: "100%", padding: "8px", background: "rgba(0,0,0,0.7)", color: "white", fontSize: "12px" }}>
                      {item.title}
                    </div>
                  </div>
                ))}
              </div>
            )}

            {/* WAVE FOOTER */}
            {block.type === "waveFooter" && (
              <div style={{ position: "relative", marginTop: "40px" }}>
                <div style={{ position: "absolute", top: 0, left: 0, width: "100%", lineHeight: 0, transform: "translateY(-99%)" }}>
                  <svg viewBox="0 0 1440 320" style={{ width: "100%", height: "auto", display: "block", transform: "rotate(180deg)" }}>
                    <path fill={block.style?.backgroundColor} fillOpacity="1" d="M0,224L48,213.3C96,203,192,181,288,181.3C384,181,480,203,576,224C672,245,768,267,864,261.3C960,256,1056,224,1152,197.3C1248,171,1344,149,1392,138.7L1440,128L1440,320L1392,320C1344,320,1248,320,1152,320C1056,320,960,320,864,320C768,320,672,320,576,320C480,320,384,320,288,320C192,320,96,320,48,320L0,320Z"></path>
                  </svg>
                </div>
                <div style={{
                  backgroundColor: block.style?.backgroundColor,
                  padding: `${block.style?.padding}px`,
                  color: block.style?.textColor,
                  textAlign: "center"
                }}>
                  <div style={{ display: "flex", justifyContent: "center", gap: "24px", marginBottom: "32px" }}>
                    {block.links?.map((link, i) => (
                      <div key={i} style={{ padding: "12px", backgroundColor: "rgba(255,255,255,0.2)", borderRadius: "50%" }}>
                        <span style={{ fontSize: "14px", fontWeight: "bold", textTransform: "capitalize" }}>{link.platform}</span>
                      </div>
                    ))}
                  </div>
                  <p style={{ opacity: 0.8, fontSize: "14px" }}>{block.content}</p>
                </div>
              </div>
            )}
          </div>
        ))}
      </div>

    </div>
  );
}



// const handleSavePreview = async () => {
//   const formData = new FormData();

//   const finalBlocks = structuredClone(previewData.blocks);
//   let imageIndex = 1; // start from 1 → images_1

//   const collectImages = async (block) => {
//     // IMAGE BLOCK
//     if (block.type === "image" && block.url?.startsWith("blob")) {
//       const response = await fetch(block.url);
//       const blob = await response.blob();

//       const fieldName = `images_${imageIndex}`;
//       const file = new File([blob], `${fieldName}.png`, {
//         type: blob.type,
//       });

//       // ✅ Append with unique key
//       formData.append(fieldName, file);

//       // ✅ Replace url with SAME key
//       block.url = fieldName;

//       imageIndex++;
//     }

//     // SECTION GRID (deep images)
//     if (block.type === "sectionGrid" && Array.isArray(block.columns)) {
//       for (const col of block.columns) {
//         for (const child of col) {
//           await collectImages(child);
//         }
//       }
//     }
//   };

//   // Extract all images
//   for (const block of finalBlocks) {
//     await collectImages(block);
//   }

//   // JSON payload
//   const contentJSON = JSON.stringify({
//     subject: previewData.subject,
//     blocks: finalBlocks,
//   });

//   formData.append("mode_of_communication", mode_of_communication.value);
//   formData.append("title", title);
//   formData.append("template_category_id", category);
//   formData.append("tags", JSON.stringify(tags));
//   formData.append("content", contentJSON);

//   await createCommunicationTemplate(formData);
//   navigate("/templates/settingList");
// };

