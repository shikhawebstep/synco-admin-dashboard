import React from 'react'

const Rewards = () => {
  return (
    <div>
      
    </div>
  )
}

export default Rewards
