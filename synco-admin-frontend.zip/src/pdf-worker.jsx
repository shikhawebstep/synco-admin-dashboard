// src/pdf-worker.js
import workerSrc from "pdfjs-dist/build/pdf.worker.min.js?url";
export default workerSrc;
